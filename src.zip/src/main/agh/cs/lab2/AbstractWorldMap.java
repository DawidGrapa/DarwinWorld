package agh.cs.lab2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class AbstractWorldMap implements IWorldMap,IPositionChangeObserver{

    protected List<Animal> animals = new ArrayList<>();
    protected Map<Vector2d,Animal> animalsHashMap = new HashMap<>();
    MapBoundary boundary = new MapBoundary();

    @Override
    public void run(MoveDirection[] directions) {
        if (!animalsHashMap.isEmpty())
            for (int i = 0; i < directions.length; i++) {
                Vector2d oldPosition = animals.get(i%animals.size()).getPosition();
                animals.get(i % animals.size()).move(directions[i]);
                Vector2d newPosition = animals.get(i%animals.size()).getPosition();
                if(!oldPosition.equals(newPosition)) {
                    boundary.deleteAnimal(animals.get(i % animals.size()));
                    animals.get(i % animals.size()).positionChanged(oldPosition, newPosition);
                    boundary.passAnimal(animals.get(i % animals.size()));
                }
    }}
    @Override
    public boolean place(Animal animal) {
        if(canMoveTo(animal.getPosition())){
            animals.add(animal);
            animal.addObserver(this);
            boundary.passAnimal(animal);
            animal.addObserver(boundary);
            animalsHashMap.put(animal.getPosition(),animal);
            return true;
        }
        throw new IllegalArgumentException(animal.getPosition() + " to zajęte pole!");
    }
    abstract Vector2d minVal();
    abstract Vector2d maxVal();  //niepotrzebne ale zostawiam

    public String toString(){
        MapVisualizer mapa = new MapVisualizer(this);
        return mapa.draw(boundary.getMinValue(), boundary.getMaxValue());
    }

    @Override
    public void positionChanged(Vector2d oldPosition, Vector2d newPosition) {
        Animal animal = animalsHashMap.get(oldPosition);
        animalsHashMap.remove(oldPosition);
        animalsHashMap.put(newPosition,animal);
    }
}
