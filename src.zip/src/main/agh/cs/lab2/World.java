package agh.cs.lab2;
import static agh.cs.lab2.MapDirection.*;
public class World {

    public static void main(String[] args) {
        try{
        String[] arguments ={"f","f","f","f","f","f","f","f","f"};

        MoveDirection[] directions = new OptionParser().parse(arguments);
        IWorldMap map = new GrassField(10);
        map.place(new Animal(map, new Vector2d(1, 0)));
        map.place(new Animal(map, new Vector2d(0, 0)));


        map.run(directions);
        System.out.print(map.toString());

        }
        catch (IllegalArgumentException ex){
            System.out.print("Dzialanie programu zakonczone z powodu: \n" + ex);
    }
    }
}

