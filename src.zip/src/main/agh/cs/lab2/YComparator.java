package agh.cs.lab2;

import java.util.Comparator;

public class YComparator implements Comparator<IMapElement> {

    @Override
    public int compare(IMapElement o1, IMapElement o2) {
        if(o1.getPosition().y>o2.getPosition().y)
            return 1;
        else if(o1.getPosition().y<o2.getPosition().y)
            return -1;
        else{
            return Integer.compare(o1.getPosition().x, o2.getPosition().x);
        }
    }
}
