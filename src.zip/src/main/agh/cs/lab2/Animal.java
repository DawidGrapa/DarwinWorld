package agh.cs.lab2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Animal implements IMapElement{
    private IWorldMap map;
    private Vector2d position= new Vector2d(2,2);
    private MapDirection direction;
    public ArrayList<IPositionChangeObserver> observers = new ArrayList<>();

    int birthDay;
    int deathDay = 0;
    Set<Animal> children = new HashSet<>();
    private float energy;

    public Animal(IWorldMap map){
        this.map=map;
        direction = MapDirection.getRandom();
    }

    public Animal(IWorldMap map, Vector2d initialPosition){
        this.position = initialPosition;
        this.map=map;
        direction = MapDirection.getRandom();
    }
    @Override
    public String toString(){
        char a=this.direction.toString().charAt(0);
        return String.valueOf(a);
    }
    @Override
    public Vector2d getPosition(){
        return this.position;
    }

    public MapDirection getOrientation(){
        return this.direction;
    }

    public void move(MoveDirection where){
        switch (where) {
            case RIGHT:
                this.direction=this.direction.next();
                break;
            case LEFT:
                this.direction=this.direction.previous();
                break;
            case FORWARD:
                if(map.canMoveTo(this.position.add(this.direction.toUnit())))
                this.position=this.position.add(this.direction.toUnit());
                break;
            case BACKWARD:
                if(map.canMoveTo(this.position.subtract(this.direction.toUnit())))
                this.position=this.position.subtract(this.direction.toUnit());
                break;
        }
    }
    public boolean isDead(int day) {
        if (energy <= 0) {
            deathDay = day;
            return true;
        }
        return false;
    }

    public int getChildCount() {
        return children.size();
    }
    public float getEnergy(){
        return this.energy;
    }



    void addObserver(IPositionChangeObserver observer){
        observers.add(observer);
    }
    void removeObserver(IPositionChangeObserver observer){
        observers.remove(observer);
    }
    void positionChanged(Vector2d oldPosition,Vector2d newPosition){
        for(IPositionChangeObserver observer : observers){
            observer.positionChanged(oldPosition,newPosition);
        }
    }

}

