package agh.cs.lab2;

public interface IMapElement {
    Vector2d getPosition();
    String toString();
}
