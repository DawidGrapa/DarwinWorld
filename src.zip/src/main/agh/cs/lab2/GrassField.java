package agh.cs.lab2;

import java.util.*;

public class GrassField extends AbstractWorldMap{
    Random generator = new Random();
    private List<Grass> gdzie_trawa = new ArrayList<>();
    private Map<Vector2d,Grass> grassHashMap = new HashMap<>();
    private int rozmiar= Integer.MAX_VALUE;

    public GrassField(int a) {
        int pokad_trawa = (int) Math.sqrt(a * 10);
        for (int i = 0; i < a; i++) {
            int x = generator.nextInt(pokad_trawa );
            int y = generator.nextInt(pokad_trawa);
            while (!(this.objectAt(new Vector2d(x, y)) == (null))) {
                x = generator.nextInt(pokad_trawa + 1);
                y = generator.nextInt(pokad_trawa + 1);
            }
            grassHashMap.put(new Vector2d(x,y),new Grass(new Vector2d(x,y)));
            gdzie_trawa.add(new Grass(new Vector2d(x, y)));
            boundary.passGrass(new Grass(new Vector2d(x,y)));
        }
    }


    @Override
    Vector2d minVal() {
        int min_x=rozmiar;
        int min_y=rozmiar;
        for(Animal animal : animals){
            Vector2d position = animal.getPosition();
            min_x=Math.min(min_x, position.x);
            min_y=Math.min(min_y, position.y);
        }
        for(Grass grass : this.gdzie_trawa){
            Vector2d position = grass.getPosition();
            min_x=Math.min(min_x, position.x);
            min_y=Math.min(min_y, position.y);
        }
        return new Vector2d(min_x,min_y);
    }

    @Override
    Vector2d maxVal() {
        int max_x=0;
        int max_y=0;

        for(Animal animal : animals){
            Vector2d position = animal.getPosition();
            max_x=Math.max(max_x, position.x);
            max_y=Math.max(max_y, position.y);

        }
        for(Grass grass : this.gdzie_trawa){
            Vector2d position = grass.getPosition();
            max_x=Math.max(max_x, position.x);
            max_y=Math.max(max_y, position.y);

        }
        return new Vector2d(max_x,max_y);
    }

    @Override
    public boolean canMoveTo(Vector2d position) {
        if(animalsHashMap.containsKey(position))
                return false;
        if(position.x<=this.rozmiar&&position.x>=0&&position.y>=0&&position.y<=this.rozmiar)
            return true;
        return false;    }


    @Override
    public Object objectAt(Vector2d position) {
        if(animalsHashMap.containsKey(position))
            return animalsHashMap.get(position).toString();

        if(grassHashMap.containsKey(position))
            return grassHashMap.get(position).toString();
        return null;
    }
    @Override
    public boolean isOccupied(Vector2d position) {
        if(animalsHashMap.containsKey(position))
            return true;
        else if(grassHashMap.containsKey(position))
            return true;

        return false;
    }

}
