import agh.cs.lab2.Vector2d;
import org.junit.Test;
import static org.junit.Assert.assertEquals;


public class Vector2dTest {

    @Test
    public void equal(){
        Vector2d position1 = new Vector2d(1,1);
        Vector2d position2 = new Vector2d(1,1);
        assert(position1.equals(position2));
    }

    @Test
    public void tostring(){
        Vector2d position1 = new Vector2d(1,1);
        assertEquals(position1.toString(),"(1,1)");
    }

    @Test
    public void precedes(){
        Vector2d position1 = new Vector2d(0,1);
        Vector2d position2 = new Vector2d(1,1);
        assert(position1.precedes(position2));
    }

    @Test
    public void follows(){
        Vector2d position1 = new Vector2d(0,1);
        Vector2d position2 = new Vector2d(1,1);
        assert(position2.follows(position1));
    }

    @Test
    public void upperRight(){
        Vector2d position1 = new Vector2d(0,1);
        Vector2d position2 = new Vector2d(1,0);
        Vector2d position3 = new Vector2d(1,1);
        assertEquals(position1.upperRight(position2),position3);
    }

    @Test
    public void lowerleft(){
        Vector2d position1 = new Vector2d(0,1);
        Vector2d position2 = new Vector2d(1,0);
        Vector2d position3 = new Vector2d(0,0);
        assertEquals(position1.lowerLeft(position2),position3);
    }

    @Test
    public void add(){
        Vector2d position1 = new Vector2d(0,1);
        Vector2d position2 = new Vector2d(1,0);
        Vector2d position3 = new Vector2d(1,1);
        assertEquals(position1.add(position2),position3);
    }

    @Test
    public void substract(){
        Vector2d position1 = new Vector2d(0,1);
        Vector2d position2 = new Vector2d(1,0);
        Vector2d position3 = new Vector2d(-1,1);
        assertEquals(position1.subtract(position2),position3);
    }

    @Test
    public void opposite(){
        Vector2d position1 = new Vector2d(1,1);
        Vector2d position2 = new Vector2d(-1,-1);
        assertEquals(position1.opposite(),position2);
    }


}
