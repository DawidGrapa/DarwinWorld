import agh.cs.lab2.*;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


public class GrassFieldTest {

    private List<Animal> animalsArrT;
    private List<Grass> grassArrT;
    GrassField map ;
    int grassArrTlength;

    @Before
    public void setUp(){
        animalsArrT = new ArrayList<>();
        grassArrT = new ArrayList<>();
        map = new GrassField(10);
        grassArrTlength= grassArrT.size();
    }

    @Test
    public void GrassFieldConstructorTest() {

        Vector2d upperGrass = new Vector2d(10,10);
        Vector2d lowerGrass = new Vector2d(0,0);
        for(Grass grass: grassArrT)
            assertTrue(grass.getPosition().precedes(upperGrass) && grass.getPosition().follows(lowerGrass));

    }
    @Test
    public void testOfMethod(){
        Vector2d position1 = new Vector2d(12, 15);
        Vector2d position2 = new Vector2d(13, 15);

        Animal animal1 = new Animal(map, position1);
        Animal animal2 = new Animal(map, position2);

        assertTrue( map.isOccupied(position1)); ;
        assertTrue(map.isOccupied(position1));

        Assert.assertEquals(map.objectAt(position1), "N");

        String[] directionArrT = {"r", "l", "f", "l","b","f"};
        MoveDirection[] directions = new OptionParser().parse(directionArrT);
        map.run(directions);

        assertEquals("E (11,15)",animal1.toString()+ ' ' + animal1.getPosition());
        assertEquals("S (13,14)",animal2.toString()+ ' ' + animal2.getPosition());

    }
}
