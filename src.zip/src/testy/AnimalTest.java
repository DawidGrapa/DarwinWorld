import agh.cs.lab2.*;
import org.junit.Test;
import static org.junit.Assert.assertEquals;



public class AnimalTest {

    IWorldMap map = new RectangularMap(6,10);
    Animal animalTest1= new Animal(map);
    Animal animalTest2= new Animal(map, new Vector2d(0,4));
    Animal animalTest3= new Animal(map, new Vector2d(5,10));

    @Test
    public void moveTest() {
        map.place(animalTest1);
        map.place(animalTest2);
        map.place(animalTest3);
        animalTest1.move(MoveDirection.LEFT);
        assertEquals("W (2,2)",animalTest1.toString() + ' ' + animalTest1.getPosition());
        animalTest1.move(MoveDirection.FORWARD);
        assertEquals("W (1,2)",animalTest1.toString()+ ' ' + animalTest1.getPosition());
/*                              WYLACZONE BO MUSIALBYM TWORZYC MAPE
    @Test
    public void position(){

        Animal animal1 = new Animal();
        Vector2d wektor = new Vector2d(2,2);
        animal1.move(MoveDirection.FORWARD);
        animal1.move(MoveDirection.FORWARD);
        wektor=wektor.add(MapDirection.NORTH.toUnit());
        wektor=wektor.add(MapDirection.NORTH.toUnit());
        assertEquals(wektor,animal1.getPosition());
    }

    @Test
    public void orientation(){
        Animal animal1 = new Animal();
        MapDirection kierunek = MapDirection.NORTH;
        animal1.move(MoveDirection.LEFT);
        animal1.move(MoveDirection.LEFT);
        kierunek = kierunek.previous();
        kierunek=kierunek.previous();
        assertEquals(kierunek,animal1.getOrientation());

    }

    @Test
    public void outOfMap(){
        Animal animal1 = new Animal();
        for(int i=0;i<10;i++)
            animal1.move(MoveDirection.FORWARD);
        Vector2d wektor = new Vector2d(2,4);
        assertEquals(animal1.getPosition(),wektor);
    }

    @Test
    public void array(){
        String[] arguments ={"l","l","r","g","to nie to:/","b","f","f","l","hehe"};
        Animal animal = new Animal();
        OptionParser ruch = new OptionParser();
        MoveDirection[] kierunki = ruch.parse(arguments);
        for(int i=0;i< kierunki.length;i++)
            animal.move(kierunki[i]);

        Animal animal1 = new Animal();
        animal.move(MoveDirection.LEFT);
        animal.move(MoveDirection.LEFT);
        animal.move(MoveDirection.RIGHT);
        animal.move(MoveDirection.BACKWARD);
        animal.move(MoveDirection.FORWARD);
        animal.move(MoveDirection.FORWARD);
        animal.move(MoveDirection.LEFT);
        assertEquals(animal.getPosition(),animal1.getPosition());
        assertEquals(animal.getOrientation(),animal1.getOrientation());
    }

*/
}}