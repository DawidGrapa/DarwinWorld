import agh.cs.lab2.MapDirection;
import org.junit.Test;
import static agh.cs.lab2.MapDirection.*;
import static org.junit.Assert.assertEquals;

public class MapDirectionTest {

    MapDirection mapka[]={NORTH,EAST,SOUTH,WEST};

    @Test

    public void next(){
        assertEquals(mapka[0].next(),EAST);
        assertEquals(mapka[1].next(),SOUTH);
        assertEquals(mapka[2].next(),WEST);
        assertEquals(mapka[3].next(),NORTH);
    }
    @Test
    public void previous(){
        assertEquals(mapka[0].previous(),WEST);
        assertEquals(mapka[1].previous(),NORTH);
        assertEquals(mapka[2].previous(),EAST);
        assertEquals(mapka[3].previous(),SOUTH);
    }
}
