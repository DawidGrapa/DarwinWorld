import agh.cs.lab2.*;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class MapTest {
    String[] testy = {"f","b","r","l","f","f","r","r","f","f","f","f","f","f","f","f"};
    MoveDirection[] directions = new OptionParser().parse(testy);
    Vector2d wektor1=new Vector2d(2,2);
    Vector2d wektor2=new Vector2d(3,3);
    Vector2d wektor3=new Vector2d(4,4);
    MapDirection kierunek1 = MapDirection.NORTH;
    MapDirection kierunek2 = MapDirection.NORTH;
    MapDirection kierunek3 = MapDirection.NORTH;

    IWorldMap map = new RectangularMap(10, 5);

    Animal animal1= new Animal(map, new Vector2d(2,2));
    Animal animal2= new Animal(map, new Vector2d(3,3));
    Animal animal3 = new Animal(map, new Vector2d(4,4));

    @Test
    public void poprawnosc(){
        map.place(animal1);
        map.place(animal2);
        map.place(animal3);
        map.run(directions);
        wektor1=wektor1.add(MapDirection.NORTH.toUnit());
        wektor2=wektor2.subtract(MapDirection.NORTH.toUnit());
        kierunek3=kierunek3.next();
        kierunek1=kierunek1.previous();
        wektor2=wektor2.add(MapDirection.NORTH.toUnit());
        wektor3=wektor3.add(MapDirection.EAST.toUnit());
        kierunek1=kierunek1.next(); //^
        kierunek2=kierunek2.next(); //->
        wektor3=wektor3.add(MapDirection.EAST.toUnit());   //->
        wektor1=wektor1.add(MapDirection.NORTH.toUnit());
        wektor2=wektor2.add(MapDirection.EAST.toUnit());
        wektor3=wektor3.add(MapDirection.EAST.toUnit());
        wektor1=wektor1.add(MapDirection.NORTH.toUnit());
        wektor2=wektor2.add(MapDirection.EAST.toUnit());
        wektor3=wektor3.add(MapDirection.EAST.toUnit());
       // wektor1=wektor1.add(MapDirection.NORTH.toUnit());   --- odpadnie bo mapa ma 5 jednostek

        assertEquals(wektor1,animal1.getPosition());
        assertEquals(kierunek1,animal1.getOrientation());
        assertEquals(wektor2,animal2.getPosition());
        assertEquals(kierunek2,animal2.getOrientation());
        assertEquals(wektor3,animal3.getPosition());
        assertEquals(kierunek3,animal3.getOrientation());
        System.out.println("I na koniec obrazowo:");
        System.out.print(( map.toString()));
    }
}
