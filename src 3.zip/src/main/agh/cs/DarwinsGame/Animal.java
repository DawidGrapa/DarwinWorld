package agh.cs.DarwinsGame;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Animal implements IMapElement{
    private MapDirection direction;
    public ArrayList<IPositionChangeObserver> observers = new ArrayList<>();
    private Genotype genotype;
    int birthDay;
    int deathDay = 0;
    Set<Animal> children = new HashSet<>();
    private float energy;
    private Vector2d position;




    @Override
    public String toString(){
        return this.direction.toString();
    }
    @Override
    public Vector2d getPosition(){
        return this.position;
    }

    public MapDirection getOrientation(){
        return this.direction;
    }

    public static buildNewAnimal buildAnimal(){
        return new buildNewAnimal();
    }

    public void move(){
        int howMany = genotype.getHowManyTimesItShouldTurns();
        for(int i=0;i<howMany;i++){
            this.direction = this.direction.next();
        }
        Vector2d ruch = this.direction.toUnit();
        Vector2d oldPosition = this.position;
        this.position=this.position.add(ruch);
        this.positionChanged(oldPosition,this.getPosition(),this);
    }


    public boolean isDead(int day) {
        if (energy <= 0) {
            deathDay = day;
            return true;
        }
        return false;
    }
    public Genotype getGenotype(){
        return this.genotype;
    }
    public int howManyChildren() {
        return children.size();
    }
    public float getEnergy(){
        return this.energy;
    }
    public void increaseEnergy(float energy){
        this.energy+=energy;
    }
    public void decreaseEnergy(float energy){
        this.energy-=energy;
    }
    public static Animal breed(Animal firstParent,Animal secondParent,Vector2d position,int birthDay){
        Animal parent1 = firstParent;
        Animal parent2 = secondParent;
        Animal baby = null;
        if(parent1.energy>3/2.0 && parent2.energy>3/2.0){
            float energy = parent1.energy / 4 + parent2.energy / 4;
            parent1.decreaseEnergy(parent1.energy/4);
            parent2.decreaseEnergy(parent2.energy/4);
            Genotype genotype = new Genotype(parent1,parent2);
            baby = Animal.buildAnimal().withPosition(position).withBirthDay(birthDay).withEnergy(energy).withGenotype(genotype).build();
        }
        return baby;

    }

    public static class buildNewAnimal{             //here i build new animal with some parameters or without
        Genotype genotype = new Genotype();
        private float energy = 3;
        private Vector2d position;
        private int birthDay;
        private MapDirection direction = MapDirection.getRandom();

        public buildNewAnimal withEnergy(float energy){
            this.energy = energy;
            return this;
        }
        public buildNewAnimal withBirthDay(int birthDay){
            this.birthDay=birthDay;
            return this;
        }
        public buildNewAnimal withPosition(Vector2d position){
            this.position = position;
            return this;
        }
        public buildNewAnimal withGenotype(Genotype genotype){
            this.genotype=genotype;
            return this;
        }
        public Animal build(){
            Animal animal = new Animal();
            animal.genotype=genotype;
            animal.energy=energy;
            animal.position=position;
            animal.birthDay=birthDay;
            animal.direction=direction;
            return animal;
        }
    }





    void addObserver(IPositionChangeObserver observer){
        observers.add(observer);
    }
    void removeObserver(IPositionChangeObserver observer){
        observers.remove(observer);
    }
    void positionChanged(Vector2d oldPosition,Vector2d newPosition,IMapElement o){
        for(IPositionChangeObserver observer : observers){
            observer.positionChanged(oldPosition,newPosition,o);
        }
    }

}

