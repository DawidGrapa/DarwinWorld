package agh.cs.DarwinsGame;

public class Grass implements IMapElement{
    private Vector2d position;
    public float energy;
    public Grass(Vector2d vector2d) {
        this.position=vector2d;

    }
    @Override
    public Vector2d getPosition(){
        return this.position;
    }
    @Override
    public String toString(){
        return "*";
    }
}
