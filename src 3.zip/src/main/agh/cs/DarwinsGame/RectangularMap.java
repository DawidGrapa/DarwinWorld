package agh.cs.DarwinsGame;

public class RectangularMap {

    private Vector2d lowerLeft;
    private Vector2d upperRight;

    public RectangularMap(Vector2d lowerLeft,Vector2d upperRight){
            this.lowerLeft=lowerLeft;
            this.upperRight = upperRight;
    }





}
