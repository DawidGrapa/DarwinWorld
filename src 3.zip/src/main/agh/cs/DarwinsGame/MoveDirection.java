package agh.cs.DarwinsGame;

public enum MoveDirection {
    FORWARD,
    BACKWARD,
    RIGHT,
    LEFT
}
