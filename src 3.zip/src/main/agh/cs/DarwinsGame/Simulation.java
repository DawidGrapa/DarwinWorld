package agh.cs.DarwinsGame;

public class Simulation {
    int day;
    AbstractWorldMap map;
    RectangularMap jungleArea;

    public Simulation(int width,int height){
        day =0;
        RectangularMap areaOfMap = new RectangularMap(new Vector2d(0,0),new Vector2d(width-1,height-1));
        Vector2d jungleLowerLeft = new Vector2d((int) 0.25*width,(int) 0.25*height);
        Vector2d jungleUpperRight = new Vector2d((int) 0.75*width,(int)0.75*height);
        jungleArea = new RectangularMap(jungleLowerLeft,jungleUpperRight);
        map = new GrassField(areaOfMap);

    }

    public void simulate(){

    }
}
