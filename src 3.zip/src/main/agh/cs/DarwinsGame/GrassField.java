package agh.cs.DarwinsGame;

import java.util.*;

public class GrassField extends AbstractWorldMap{
    private List<Grass> gdzie_trawa = new ArrayList<>();
    private int rozmiar= Integer.MAX_VALUE;
    RectangularMap area;

    public GrassField(RectangularMap area) {
        this.area=area;
    }

}
