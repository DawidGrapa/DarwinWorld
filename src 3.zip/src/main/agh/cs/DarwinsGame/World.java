package agh.cs.DarwinsGame;

public class World {

    public static void main(String[] args) {
        try{

        }
        catch (IllegalArgumentException ex){
            System.out.print("Dzialanie programu zakonczone z powodu: \n" + ex);
    }
    }
}

