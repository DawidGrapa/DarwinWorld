package agh.cs.DarwinsGame;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class Genotype {
    public int genomeSize = 32;
    public int howManyGenes=8;
    int [] isThereEveryGene = new int[howManyGenes];
    List<Integer> genes = new ArrayList<>(32);

    Genotype(){
        for(int i=0;i<howManyGenes;i++){
            genes.add(i);
        }
        for(int i=howManyGenes;i<genomeSize;i++){
            genes.add(ThreadLocalRandom.current().nextInt(howManyGenes));
        }
        genes.sort(Integer::compareTo);

    }
    Genotype(Animal parent1,Animal parent2){
        Genotype genotype1 = parent1.getGenotype();
        Genotype genotype2 = parent2.getGenotype();
        int firstCut = ThreadLocalRandom.current().nextInt(1, 15);
        int secondCut = ThreadLocalRandom.current().nextInt(firstCut, 31);
        int[] isThereEveryGene = new int[howManyGenes];
        Arrays.fill(isThereEveryGene, 0);
        for(int i=0;i<genomeSize;i++){
            if(i<firstCut) isThereEveryGene[genotype1.genes.get(i)]++;
            else if(i>=firstCut &&i<secondCut) isThereEveryGene[genotype2.genes.get(i)]++;
            else isThereEveryGene[genotype1.genes.get(i)]++;
        }

    }



    public int getHowManyTimesItShouldTurns(){
        return this.genes.get(ThreadLocalRandom.current().nextInt(genomeSize-1));
    }
}
