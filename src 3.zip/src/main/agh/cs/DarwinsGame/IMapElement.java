package agh.cs.DarwinsGame;

public interface IMapElement {
    String toString();
    Vector2d getPosition();
}
