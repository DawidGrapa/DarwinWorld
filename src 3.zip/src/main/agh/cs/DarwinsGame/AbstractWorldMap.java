package agh.cs.DarwinsGame;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class AbstractWorldMap implements IPositionChangeObserver{

    protected List<Animal> animals = new ArrayList<>();
    protected Map<Vector2d,List<Animal>> animalsHashMap = new HashMap<>();
    protected Map<Vector2d,Grass> grassHashMap = new HashMap<>();




    @Override
    public void positionChanged(Vector2d oldPosition, Vector2d newPosition,IMapElement o) {
        List<Animal> anml = animalsHashMap.get(oldPosition);
        for(Animal animal : anml){
            if(animal.equals(o)){
                Animal stary = animal;
                anml.remove(animal);
                List<Animal> anml1 = animalsHashMap.computeIfAbsent(newPosition, k -> new ArrayList<Animal>());
                anml1.add(stary);
                break;
            }
        }
    List<Animal> list = animalsHashMap.get(oldPosition);
    if(list.isEmpty()){
        animalsHashMap.remove(oldPosition);
    }

    }
}
