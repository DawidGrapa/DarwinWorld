

import agh.cs.lab2.*;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class RectangularMapTest {

    IWorldMap map = new RectangularMap(4,5);
    String[] directionArrTest = {"f","b","f",  "b","f","coś","l",  "l","r","b", "f","right","left"};
    MoveDirection[] resultArr = OptionParser.parse(directionArrTest);

    @Test
    public void oneRectangularMapTest(){
        List<Animal> animalsTestArray = new ArrayList<>();
        Animal animalTest1= new Animal(map,new Vector2d(2,2));
        Animal animalTest2= new Animal(map, new Vector2d(1,2));
        Animal animalTest3= new Animal(map, new Vector2d(4,5));

        map.place(animalTest1);
        map.place(animalTest2);
        map.place(animalTest3);
        System.out.print(resultArr[0]);
        map.run(resultArr);
        System.out.print(animalTest1.toString());
        assertEquals("W (2,2)",animalTest1.toString()+ ' ' + animalTest1.getPosition());
        assertEquals("S (1,2)",animalTest2.toString()+ ' ' + animalTest2.getPosition());
        assertEquals("S (4,5)",animalTest3.toString()+ ' ' + animalTest3.getPosition());


    }

    @Test
    public void isOccupiedTest()
    {
        Animal animalTest1= new Animal(map, new Vector2d(1,2));
        assertTrue(map.isOccupied(animalTest1.getPosition()));
        map.place(animalTest1);
        assertTrue(map.isOccupied(animalTest1.getPosition()));

    }
    /*@Test
    public void objectAtTest()
    {
        Animal animalTest1= new Animal(map, new Vector2d(4,5));
        map.place(animalTest1);
        assertEquals(new Vector2d(4,5), animalTest1.getPosition());
        animalTest1.move(MoveDirection.BACKWARD);
        assertEquals(new Vector2d(4,4), animalTest1.getPosition());
        animalTest1.move((MoveDirection.RIGHT));
        assertEquals(new Vector2d(4,4), animalTest1.getPosition());
    }*/
}
