package agh.cs.lab2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Animal implements IMapElement{
    private IWorldMap map;
    private Vector2d position= new Vector2d(2,2);
    private MapDirection direction;
    public ArrayList<IPositionChangeObserver> observers = new ArrayList<>();
    Genotype genotype;
    int birthDay;
    int deathDay = 0;
    Set<Animal> children = new HashSet<>();
    private float energy;

    public Animal(IWorldMap map){
        this.map=map;
        this.direction = MapDirection.getRandom();
        this.genotype=new Genotype();
    }

    public Animal(IWorldMap map, Vector2d initialPosition){
        this.position = initialPosition;
        this.map=map;
        this.direction = MapDirection.getRandom();
        this.genotype=new Genotype();
    }
    @Override
    public String toString(){
        return this.direction.toString();
    }
    @Override
    public Vector2d getPosition(){
        return this.position;
    }

    public MapDirection getOrientation(){
        return this.direction;
    }

    public void move(){
        int howMany = genotype.getHowManyTimesItShouldTurns();
        for(int i=0;i<howMany;i++){
            this.direction = this.direction.next();
        }
        Vector2d ruch = this.direction.toUnit();
        this.position=this.position.add(ruch);
    }
    public boolean isDead(int day) {
        if (energy <= 0) {
            deathDay = day;
            return true;
        }
        return false;
    }

    public int getChildCount() {
        return children.size();
    }
    public float getEnergy(){
        return this.energy;
    }



    void addObserver(IPositionChangeObserver observer){
        observers.add(observer);
    }
    void removeObserver(IPositionChangeObserver observer){
        observers.remove(observer);
    }
    void positionChanged(Vector2d oldPosition,Vector2d newPosition,Object o){
        for(IPositionChangeObserver observer : observers){
            observer.positionChanged(oldPosition,newPosition,o);
        }
    }

}

