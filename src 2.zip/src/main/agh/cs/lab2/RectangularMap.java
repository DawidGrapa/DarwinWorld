package agh.cs.lab2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RectangularMap extends AbstractWorldMap{



    public RectangularMap(int width,int height){
        if((width>0 && height>0)) {
            this.height = height;
            this.width=width;
        }
    }
    private int height;
    private int width;

    @Override
    Vector2d minVal() {
        return new Vector2d(0,0);
    }

    @Override
    Vector2d maxVal() {
        return new Vector2d(width,height);
    }

    @Override
    public boolean canMoveTo(Vector2d position) {
        if(position.x<=this.width&&position.x>=0&&position.y>=0&&position.y<=this.height&&!isOccupied(position))
            return true;
        return false;
    }


    @Override
    public Object objectAt(Vector2d position) {
        if(animalsHashMap.containsKey(position))
            return animalsHashMap.get(position).toString();
        return null;
    }
    @Override
    public boolean isOccupied(Vector2d position) {
        if(animalsHashMap.containsKey(position))
            return true;

        return false;
    }
}
