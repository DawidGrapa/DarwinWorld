package agh.cs.lab2;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class Genotype {
    public int genomeSize = 32;
    private int howManyGenes=8;

    List<Integer> genes = new ArrayList<>(32);

    Genotype(){
        for(int i=0;i<howManyGenes;i++){
            genes.add(i);
        }
        for(int i=howManyGenes;i<genomeSize;i++){
            genes.add(ThreadLocalRandom.current().nextInt(howManyGenes));
        }
        genes.sort(Integer::compareTo);

    }



    public int getHowManyTimesItShouldTurns(){
        return this.genes.get(ThreadLocalRandom.current().nextInt(genomeSize-1));
    }
}
