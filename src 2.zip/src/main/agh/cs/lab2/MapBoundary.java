package agh.cs.lab2;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.SortedSet;
import java.util.TreeSet;

public class MapBoundary implements IPositionChangeObserver  {
    Comparator yComparator = new YComparator();
    Comparator xComparator = new XComparator();
    SortedSet<IMapElement> yAnimalSorted = new TreeSet<IMapElement>(yComparator);
    SortedSet<IMapElement> xAnimalSorted = new TreeSet<IMapElement>(xComparator);
    SortedSet<IMapElement> xGrassSorted = new TreeSet<IMapElement>(xComparator);
    SortedSet<IMapElement> yGrassSorted = new TreeSet<IMapElement>(yComparator);

    public void passAnimal(Animal animal){
        yAnimalSorted.add(animal);
        xAnimalSorted.add(animal);
    }
    public void deleteAnimal(Animal animal){
        xAnimalSorted.remove(animal);
        yAnimalSorted.remove(animal);
    }
    public void passGrass(Grass grass){
        xGrassSorted.add(grass);
        yGrassSorted.add(grass);
        //System.out.println(xGrassSorted.size());   to mozna odznaczyc zeby zobaczyc ze faktycznie jest 1000 traw
    }
    public Vector2d getMinValue(){
        return new Vector2d(Math.min(xGrassSorted.first().getPosition().x,xAnimalSorted.first().getPosition().x),Math.min(yGrassSorted.first().getPosition().y,yAnimalSorted.first().getPosition().y));
    }
    public Vector2d getMaxValue(){
        return new Vector2d(Math.max(xGrassSorted.last().getPosition().x,xAnimalSorted.last().getPosition().x),Math.max(yGrassSorted.last().getPosition().y,yAnimalSorted.last().getPosition().y));
    }

    @Override
    public void positionChanged(Vector2d oldPosition, Vector2d newPosition,Object o) {
        //sposob troche inny niz oczekiwany ale dziala :)))
        //moze w skrocie opisze: 4 sorted sety po dwa na kazda klase
        //jesli zwierze zmieni pozycje to usuwam z sorted seta zwierzat to zwierze i dodaje je z nowa pozycja
        //za pomoca ,metod passAnimal i deleteAnimal
        //wywolanie tych metod jest w metodzie run
        //nie chcialem miec 1 sorted seta bo cos sie psulo przy porownywaniu klas, oraz jak zwierze sie poruszylo
        // i roslina miala ta pozycje na ktora zwierze chcialo isc to roslina znikala z sorted seta :////
        //ten spoosb jest dla mnie po prostu bardziej zrozumialy i czytelny
        //mam pewne obawy co do tego ze w tych sorted setach maja byc po prostu 2 wartosci, ale ciezko z tego polecenia
        //wyciagnac sensowne wnioski wiec zapytam o to na zajeciach :)
    }
}
