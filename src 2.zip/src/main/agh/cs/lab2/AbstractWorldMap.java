package agh.cs.lab2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class AbstractWorldMap implements IWorldMap,IPositionChangeObserver{

    protected List<Animal> animals = new ArrayList<>();
    protected Map<Vector2d,List<Animal>> animalsHashMap = new HashMap<>();
    MapBoundary boundary = new MapBoundary();

    @Override
    public void run(MoveDirection[] directions) {
        if (!animalsHashMap.isEmpty())
            for (int i = 0; i < directions.length; i++) {
                Vector2d oldPosition = animals.get(i%animals.size()).getPosition();
                animals.get(i % animals.size()).move();
                Vector2d newPosition = animals.get(i%animals.size()).getPosition();
                if(!oldPosition.equals(newPosition)) {
                    boundary.deleteAnimal(animals.get(i % animals.size()));
                    animals.get(i % animals.size()).positionChanged(oldPosition, newPosition,animals.get(i % animals.size()));
                    boundary.passAnimal(animals.get(i % animals.size()));
                }
    }}
    @Override
    public boolean place(Animal animal) {
        if(canMoveTo(animal.getPosition())){
            animals.add(animal);
            animal.addObserver(this);
            boundary.passAnimal(animal);
            animal.addObserver(boundary);
            List<Animal> anml = animalsHashMap.get(animal.getPosition());
            if(anml==null){
                anml = new ArrayList<Animal>();
                animalsHashMap.put(animal.getPosition(),anml);
            }
            anml.add(animal);
            return true;
        }
        throw new IllegalArgumentException(animal.getPosition() + " to zajęte pole!");
    }
    abstract Vector2d minVal();
    abstract Vector2d maxVal();  //niepotrzebne ale zostawiam

    public String toString(){
        MapVisualizer mapa = new MapVisualizer(this);
        return mapa.draw(boundary.getMinValue(), boundary.getMaxValue());
    }

    @Override
    public void positionChanged(Vector2d oldPosition, Vector2d newPosition,Object o) {
        List<Animal> anml = animalsHashMap.get(oldPosition);
        for(Animal animal : anml){
            if(animal.equals(o)){
                Animal stary = animal;
                anml.remove(animal);
                List<Animal> anml1 = animalsHashMap.get(newPosition);
                if(anml1==null){
                    anml1 = new ArrayList<Animal>();
                    animalsHashMap.put(newPosition,anml1);
                }
                anml1.add(stary);
                break;
            }
        }
    List<Animal> list = animalsHashMap.get(oldPosition);
    if(list.isEmpty()){
        animalsHashMap.remove(oldPosition);
    }

    }
}
