package agh.cs.lab2;

public class OptionParser {  //SZKODA ZE TABLICA A NIE LISTA ;/
    public static MoveDirection[] parse(String[] movedirection){

        int num=0;
        for(int i=0;i< movedirection.length;i++)
        {
            if(movedirection[i]=="f"||movedirection[i]=="forward"||movedirection[i]=="b"||movedirection[i]=="backward"
            ||movedirection[i]=="l"||movedirection[i]=="left"||movedirection[i]=="r"||movedirection[i]=="right")
                num+=1;
        }
        int j=0;
        MoveDirection[] dozwrotu = new MoveDirection[num];
        for(int i=0;i< movedirection.length;i++)
            switch (movedirection[i]){
                case "f":
                    dozwrotu[j]=MoveDirection.FORWARD;
                    j+=1;
                    break;
                case "forward":
                    dozwrotu[j]=MoveDirection.FORWARD;
                    j+=1;
                    break;
                case "b":
                    dozwrotu[j]=MoveDirection.BACKWARD;
                    j+=1;
                    break;
                case "backward":
                    dozwrotu[j]=MoveDirection.BACKWARD;
                    j+=1;
                    break;
                case "r":
                    dozwrotu[j]=MoveDirection.RIGHT;
                    j+=1;
                    break;
                case "right":
                    dozwrotu[j]=MoveDirection.RIGHT;
                    j+=1;
                    break;
                case "l":
                    dozwrotu[j]=MoveDirection.LEFT;
                    j+=1;
                    break;
                case "left":
                    dozwrotu[j]=MoveDirection.LEFT;
                    j+=1;
                    break;
                default:
                    throw new IllegalArgumentException(movedirection[i]+" is not legal move specification");
            }
        return dozwrotu;
    }
}
